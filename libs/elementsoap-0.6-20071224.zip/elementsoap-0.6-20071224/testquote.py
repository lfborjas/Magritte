# $Id: testquote.py 2927 2006-11-20 19:35:27Z fredrik $
# delayed stock quote demo (www.xmethods.com)

from elementsoap.ElementSOAP import *

class QuoteService(SoapService):
    url = "http://64.124.140.30:9090/soap"
    def getQuote(self, symbol):
        action = "urn:xmethods-delayed-quotes#getQuote"
        request = SoapRequest("{urn:xmethods-delayed-quotes}getQuote")
        SoapElement(request, "symbol", "string", symbol)
        response = self.call(action, request)
        return float(response.findtext("Result"))

q = QuoteService()
print "MSFT", q.getQuote("MSFT")
print "LNUX", q.getQuote("LNUX")
